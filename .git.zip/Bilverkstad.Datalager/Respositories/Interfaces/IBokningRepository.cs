﻿using Bilverkstad.Datalager.Respositories.BaseRepository;

namespace Bilverkstad.Datalager.Respositories.Interfaces
{
    public interface IBokningRepository : IBaseRepository<Bokning>
    {
    }
}