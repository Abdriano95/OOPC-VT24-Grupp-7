﻿SELECT *
FROM Fordon